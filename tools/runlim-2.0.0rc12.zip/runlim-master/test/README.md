These tests provide some hard to monitor examples for 'runlim' and
are far from being automatic tests.
